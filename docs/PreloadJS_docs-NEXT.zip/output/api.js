YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "AbstractLoader",
        "EventDispatcher",
        "Listener",
        "PreloadJS",
        "TagLoader",
        "XHRLoader"
    ],
    "modules": [
        "PreloadJS"
    ],
    "allModules": [
        {
            "displayName": "PreloadJS",
            "name": "PreloadJS",
            "description": "PreloadJS provides a consistent way to preload content for use in HTML applications. Preloading can be done using\nHTML tags, as well as XHR. By default, PreloadJS will try and load content using XHR, since it provides better\nsupport for progress and completion events, however due to cross-domain issues, it may still be preferable to use\ntag-based loading instead. Note that some content requires XHR to work (plain text, web audio), and some requires\ntags (HTML audio).\n<br/><br/>\nPreloadJS currently supports all modern browsers, and we have done our best to include support for most older\nbrowsers is included. If you find an issue with any specific OS/browser combination, please visit\nhttp://community.createjs.com/ and report it.\n<br/><br/>\nTo get started:\n<ol>\n    <li>Create a preload queue. An instance of PreloadJS is all you need.</li>\n    <li>Register any plugins you need. For example, if loading audio for playback with SoundJS, it is recommended\n    to install SoundJS as a plugin.</li>\n    <li>Subscribe to events. You can get notified of overall progress, item progress, overall completion,\n    item completion, and errors.</li>\n    <li>Load a file or manifest using <code>loadFile()</code> or <code>loadManifest()</code>. You can pass a simple\n         string, an object with additional parameters and data, or even an HTML tag.</li>\n    <li>Once your file or queue is loaded, look up results in event objects, or using simple APIs to use in your HTML\n         applications.</li>\n</ol>\n\nLoaded content can be accessed as the \"result\" of a fileLoad event, or looked up using the <code>getResult(id)</code>\nmethod. This will always be the usable content, including:\n<ul>\n    <li>Image: An &lt;img /&gt; tag</li>\n    <li>Audio: An &lt;audio /&gt; tag</a>\n    <li>JavaScript: A &lt;script /&gt; tag</li>\n    <li>CSS: A &lt;link /&gt; tag (tag loading) or a &lt;style /&gt; tag (xhr loading)</li>\n    <li>XML: An XML DOM node</li>\n    <li>SVG: An &lt;object /&gt; tag (tag loading) or a &lt;svg /&gt; tag (xhr loading)</li>\n    <li>JSON: A formatted JavaScript Object</li>\n    <li>Text: Raw text</li>\n    <li>Binary: The binary loaded result</li>\n</ul>\n\nRaw loaded content can be accessed using the \"rawResult\" property of the fileLoad event, or can be looked up using\n<code>getResult(id, true)</code>. This is only applicable for content that has been parsed for the browser,\nspecifically, JavaScript, CSS, XML, SVG, and JSON objects."
        }
    ]
} };
});